def carica_frasi_da_file(nome_file):
    try:
        with open(nome_file, 'r') as file:
            frasi = file.readlines()
        return [frase.strip() for frase in frasi]
    except FileNotFoundError:
        print(f"Il file '{nome_file}' non è stato trovato.")
        return []

def elimina_duplicati(frasi):
    frasi_senza_duplicati = list(set(frasi))
    return frasi_senza_duplicati

def salva_frasi_su_file(nome_file, frasi):
    with open(nome_file, 'w') as file:
        for frase in frasi:
            file.write(f"{frase}\n")

def main():
    nome_file_input = input("Inserisci il nome del file contenente le frasi: ")
    frasi = carica_frasi_da_file(nome_file_input)

    if frasi:
        frasi_senza_duplicati = elimina_duplicati(frasi)

        print("Frasi originali:")
        for frase in frasi:
            print(frase)

        print("\nFrasi senza duplicati:")
        for frase in frasi_senza_duplicati:
            print(frase)

        nome_file_output = input("\nInserisci il nome del file dove salvare le frasi senza duplicati: ")
        salva_frasi_su_file(nome_file_output, frasi_senza_duplicati)
        print(f"Le frasi senza duplicati sono state salvate nel file '{nome_file_output}'.")

if __name__ == "__main__":
    main()
